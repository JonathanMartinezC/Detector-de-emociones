document.addEventListener('DOMContentLoaded', function () {
    const uploadButton = document.getElementById('uploadButton');
    const captureButton = document.getElementById('captureButton');
    const videoButton = document.getElementById('videoButton');
    const uploadSection = document.getElementById('uploadSection');
    const captureSection = document.getElementById('captureSection');
    const videoSection = document.getElementById('videoSection');
    const displaySection = document.getElementById('displaySection');
    const video = document.getElementById('video');
    const realTimeVideo = document.getElementById('realTimeVideo');
    const canvas = document.getElementById('canvas');
    const displayImage = document.getElementById('displayImage');
    const displayVideo = document.getElementById('displayVideo');
    let videoStream = null;
    let intervalId = null;
    const exitUpload = document.getElementById('exitUpload');
    const exitCapture = document.getElementById('exitCapture');
    const exitVideo = document.getElementById('exitVideo');

    exitUpload.addEventListener('click', () => location.reload());
    exitCapture.addEventListener('click', () => location.reload());
    exitVideo.addEventListener('click', () => location.reload());

    function hideAllSections() {
        uploadSection.style.display = 'none';
        captureSection.style.display = 'none';
        videoSection.style.display = 'none';
        displayImage.style.display = 'none';
        displayVideo.style.display = 'none';
        clearResult();
    }

    function stopMediaTracks() {
        if (videoStream) {
            const tracks = videoStream.getTracks();
            tracks.forEach(track => track.stop());
            videoStream = null;
        }
        if (intervalId) {
            clearInterval(intervalId);
            intervalId = null;
        }
        video.srcObject = null;
        realTimeVideo.srcObject = null;
    }

    function clearResult() {
        document.getElementById('result').innerHTML = '';
    }

    uploadButton.addEventListener('click', () => {
        stopMediaTracks();
        hideAllSections();
        uploadSection.style.display = 'block';
        displaySection.style.display = 'block';
    });

    captureButton.addEventListener('click', () => {
        stopMediaTracks();
        hideAllSections();
        captureSection.style.display = 'block';
        displaySection.style.display = 'block';
        startVideoCapture();
    });

    videoButton.addEventListener('click', () => {
        stopMediaTracks();
        hideAllSections();
        videoSection.style.display = 'block';
        displaySection.style.display = 'block';
        startRealTimeVideo();
    });

    document.getElementById('uploadSubmit').addEventListener('click', () => {
        const fileInput = document.getElementById('uploadInput');
        const file = fileInput.files[0];
        if (file) {
            const formData = new FormData();
            formData.append('imagen', file);
            fetch('/detect_emotion/', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(data, 'text/html');
                const resultElement = doc.querySelector('#result');
                if (resultElement) {
                    clearResult();
                    document.getElementById('result').innerHTML = resultElement.innerHTML;
                } else {
                    clearResult();
                    document.getElementById('result').innerHTML = 'No se pudo extraer la información';
                }
            })
            .catch(error => console.error('Error al subir la imagen:', error));
        }
    });

    document.getElementById('snap').addEventListener('click', () => {
        const context = canvas.getContext('2d');
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => {
            const formData = new FormData();
            formData.append('imagen', blob);
            fetch('/detect_emotion/', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(data, 'text/html');
                const resultElement = doc.querySelector('#result');
                if (resultElement) {
                    clearResult();
                    document.getElementById('result').innerHTML = resultElement.innerHTML;
                } else {
                    clearResult();
                    document.getElementById('result').innerHTML = 'No se pudo extraer la información';
                }
            })
            .catch(error => console.error('Error al capturar imagen:', error));
        });
    });

    function startVideoCapture() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                videoStream = stream;
                video.srcObject = stream;
                video.play();
                displayVideo.style.display = 'block';
            })
            .catch(err => console.error('Error al iniciar la cámara: ', err));
    }

    function startRealTimeVideo() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                videoStream = stream;
                realTimeVideo.srcObject = stream;
                realTimeVideo.play();
                displayVideo.style.display = 'block';
                intervalId = setInterval(captureFrame, 5000);//Para mtcnn
                //intervalId = setInterval(captureFrame, 5000);//Para fastmtcnn
            })
            .catch(err => console.error('Error al iniciar video en tiempo real: ', err));
    }

    function captureFrame() {
        const context = canvas.getContext('2d');
        context.drawImage(realTimeVideo, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(blob => {
            const formData = new FormData();
            formData.append('imagen', blob);
            fetch('/detect_emotion/', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(data, 'text/html');
                const resultElement = doc.querySelector('#result');
                if (resultElement) {
                    document.getElementById('result').innerHTML = resultElement.innerHTML;
                } else {
                    document.getElementById('result').innerHTML = 'No se pudo extraer la información';
                }
            })
            .catch(error => console.error('Error al capturar fotograma:', error));
        });
    }

    document.getElementById('stopVideo').addEventListener('click', stopMediaTracks);
});
