from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import os
from django.views.decorators.csrf import csrf_exempt
from deepface import DeepFace
import cv2
import mediapipe as mp
from django.core.files.uploadedfile import InMemoryUploadedFile
import numpy as np
import base64
conteoEmociones = []
count = 0
countConf = 0
countfrust = 0
emocionesTraduccion = {
    'angry': 'enojado',
    'disgust': 'disgustado',
    'fear': 'miedo',
    'happy': 'feliz',
    'sad': 'triste',
    'surprise': 'sorprendido',
    'neutral': 'neutral'
}
def frust_conf(emociones, emocionDominante, dominanteValor):
    global count, countConf, countfrust
    count += 1
    fear = emociones['fear']
    surprise = emociones['surprise']
    sad = emociones['sad']
    angry = emociones['angry']
    disgust = emociones['disgust']
    umbral_confusion = 20 
    umbral_frustracion = 20 
    rango_diferencia = 20
    confusion = fear + sad + surprise
    frustracion = angry + disgust + sad
    print(f"fear: {fear}, sad: {sad}, surprise: {surprise}")
    print(f"angry: {angry}, sad: {sad}, disgust: {disgust}")
    conteoEmociones.append({
        'conteo': conteoEmociones[-1]['conteo'] + 1 if conteoEmociones else 1,
        'fear': fear,
        'sad': sad,
        'surprise': surprise,
        'angry': angry,
        'disgust': disgust,
        'dominant emotion': emocionDominante
    })

    if ((fear >= umbral_confusion and sad >= umbral_confusion) or
        (sad >= umbral_confusion and surprise >= umbral_confusion) or
        (fear >= umbral_confusion and surprise >= umbral_confusion)) and \
        (((abs(fear - sad) <= rango_diferencia) or (abs(sad - fear) <= rango_diferencia)) or
         ((abs(sad - surprise) <= rango_diferencia) or (abs(surprise - sad) <= rango_diferencia)) or
         ((abs(fear - surprise) <= rango_diferencia) or (abs(surprise - fear) <= rango_diferencia)) and \
        dominanteValor <= (fear + sad + surprise)):
        confusion = max(confusion, 0)
    else:
        confusion = 0 
    if ((angry >= umbral_frustracion and sad >= umbral_frustracion) or
        (sad >= umbral_frustracion and disgust >= umbral_frustracion) or
        (angry >= umbral_frustracion and disgust >= umbral_frustracion)) and \
        (((abs(angry - sad) <= rango_diferencia) or (abs(sad - angry) <= rango_diferencia)) or 
         ((abs(sad - disgust) <= rango_diferencia) or (abs(disgust - sad) <= rango_diferencia)) or 
         ((abs(angry - sad) <= rango_diferencia) or (abs(sad - angry) <= rango_diferencia)) and \
        dominanteValor <= (angry + disgust + sad)):
        frustracion = max(frustracion, 0) 
    else:
        frustracion = 0 
    return confusion, frustracion
def process_image(image_data):
    global count, countConf, countfrust
    try:
        detectorRostro = mp.solutions.face_mesh.FaceMesh(max_num_faces=1, min_detection_confidence=0.5)
        imagen = cv2.imdecode(np.frombuffer(image_data, np.uint8), cv2.IMREAD_COLOR)
        imagen = cv2.resize(imagen, (540, 300), interpolation=cv2.INTER_CUBIC)
        rgb = cv2.cvtColor(imagen, cv2.COLOR_BGR2RGB)
        resultadoRostro = detectorRostro.process(rgb)


        if resultadoRostro.multi_face_landmarks:
            emociones = DeepFace.analyze(img_path=imagen, actions=['emotion'], enforce_detection=False, detector_backend='mtcnn') #Motor mas preciso
            #emociones = DeepFace.analyze(img_path=imagen, actions=['emotion'], enforce_detection=False, detector_backend='fastmtcnn') #Motor mas rapido 
            print(f"Resultado de DeepFace.analyze: {emociones}")
            emocionDominante = max(emociones[0]['emotion'], key=emociones[0]['emotion'].get)
            emocion = emocionesTraduccion.get(emocionDominante, 'indefinido')
            dominanteValor = emociones[0]['emotion'][emocionDominante]

            confusion, frustracion = frust_conf(emociones[0]['emotion'], emocionDominante, dominanteValor)
            if confusion > 40 and ((confusion > frustracion) and dominanteValor < confusion):
                emocion = 'confundido'
                print(f"Confusión detectada con {confusion}")
                countConf += 1
            elif frustracion > 40 and ((frustracion > confusion) and dominanteValor < frustracion):
                emocion = 'frustrado'
                print(f"Frustración detectada con {frustracion}") 
                countfrust += 1
            return {'Emocion': emocion}
        else:
            return {'error': 'No se detectaron rostros en la imagen.'}
    except Exception as e:
        return {'error': str(e)}

@csrf_exempt
def detect_emotion(request):
    if request.method == 'POST':
        if 'imagen' in request.FILES:
            archivo_imagen = request.FILES['imagen']
            image_data = archivo_imagen.read()
        elif 'image_data' in request.POST:
            image_data = base64.b64decode(request.POST['image_data'].split(',')[1])
        else:
            return render(request, 'index.html', {'error': 'No se envió imagen'})

        resultado = process_image(image_data)
        
        if 'error' in resultado:
            return render(request, 'index.html', {'error': resultado['error']})
        return render(request, 'index.html', {'emocion': resultado['Emocion'], 'imagen_data': image_data})
    return render(request, 'index.html')



from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login as auth_login, logout as auth_logout

@login_required
def protected_view(request):
    return render(request, 'protected.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('protected_view')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

def login(request):
    return render(request, 'login.html')

def logout(request):
    auth_logout(request)
    return redirect('login')




